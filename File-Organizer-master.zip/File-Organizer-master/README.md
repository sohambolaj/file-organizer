# File-Organizer

A Python Script used to manage junk objects in a folder. It can be used by running the script in a given folder and it will automatically move all music files to music folder, image files to picture folder etc. After doing its task the python script will self destroy itself.  

The python script is also converted to an executable file inorder achive low execution time and system independence. 

**Libraries:** *os*, *pathlib* and *shutil* 
